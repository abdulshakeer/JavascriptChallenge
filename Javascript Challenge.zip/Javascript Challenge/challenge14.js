function stringremove(str){
    const l = str.length;
    return str.substr(1,l-2);
}

console.log(stringremove("abdulshakir"));