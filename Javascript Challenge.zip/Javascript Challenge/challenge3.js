function reverse(){
    var str = "hello";
    m = str.split("");
    z = m.reverse();
    i = z.join("")
    console.log(i);

}
reverse()