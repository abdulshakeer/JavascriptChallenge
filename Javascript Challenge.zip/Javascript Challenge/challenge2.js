function getPlanetName(ch){
    let name;
    switch(ch){
        case 1:
            name = 'mercury'  
            console.log(name);
            break
        case 2:
            name = 'Venus'  
            console.log(name);
            break
        case 3:
            name = 'Earth'  
            console.log(name);
            break
        case 4:
            name = 'Mars'  
            console.log(name);
            break
        case 5:
            name = 'Jupyter'  
            console.log(name);
            break
        case 6:
            name = 'Saturn'  
            console.log(name);
            break
        case 7:
            name = 'Uranus'  
            console.log(name);
            break
        case 8:
            name = 'Neptune'  
            console.log(name);
            break
    }
}
getPlanetName(6)
