function century(year){
    return Math.ceil(year/100)
}

console.log(century(1705));