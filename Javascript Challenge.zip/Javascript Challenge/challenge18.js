function strtoarray(str){
    return str.split("");
}

console.log(strtoarray("shakir"));

