function even_odd(number){
    if (number % 2 == 0){
        console.log("Its Even");
    }
    else{
        console.log("Its Odd");
    }
}

even_odd(0)