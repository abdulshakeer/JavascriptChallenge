function hero(bullet,dragons){
    return bullet/dragons >= 2 ?true:false;
}

console.log(hero(3,1));