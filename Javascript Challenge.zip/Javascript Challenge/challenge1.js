function multiply(a,b){
    return a * b;
}

console.log(multiply(10,5))


mult = (a,b) => a*b;
console.log(mult(2,2))