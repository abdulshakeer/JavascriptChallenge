var summation = function(num){
    var sum = 0;
    for(let i=1;i <= num;i++){
        sum = sum + i;

    }
    console.log(sum);
}
summation(8)
