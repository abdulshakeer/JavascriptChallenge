function greet(name){
    if(name === "Jhonny")
        return "Hello My Love";
    return "Hello "+name+"!";

}
console.log(greet("Jhonny"));
